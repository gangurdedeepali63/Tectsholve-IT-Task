<html>
<head>
	<title>Contact Form</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
</head>
<body>

	<div class="container">
		<div class="card">
			<div class="col-md-2"></div>
			<div class="col-md-8">
				<form action="<?php $_SERVER['PHP_SELF']?>" method="POST" class="form-class">
					<input type="text" name="fullname" id="fullname" placeholder="Fullname" class="mt-2" required><br>
					<input type="tel" name="phone" id="phone" placeholder="Phonenumber" max="10" class="mt-2" required><br>
					<input type="email" name="email" id="email" placeholder="Email" class="mt-2" required><br>
					<input type="text" name="subject" id="subject" placeholder="Subject" class="mt-2" required><br>
					<textarea name="message" id="message" class="mt-2" placeholder="Message"></textarea><br>
					<input type="submit" name="submit" value="Send" class="mt-2">
				</form>
			</div>
			<div class="col-md-2">
		</div>

	</div>


	<?php
	$conn = mysqli_connect('localhost', 'root', '', 'contact_form_task');
	
	if(isset($_POST['submit'])){
		$fname = htmlspecialchars(trim($_POST['fullname']));

		$email = htmlspecialchars(trim(filter_var($_POST['email'])));
		$subject = htmlspecialchars(trim($_POST['subject']));

		$message = htmlspecialchars(trim($_POST['message']));
		$phone = $_POST['phone'];
		$ip_address = getenv('REMOTE_ADDR');
		$current_datetime = date('Y-m-d H:i:s');
		
		$sql = "select * from contact_form where email='".$email."'";
		$existingres = $conn->query($sql);
		
		$row = mysqli_num_rows($existingres);
		if($row == 1){
			
		}else{
			$query = 'insert into contact_form (name, phone, email, subject, message, ip_address, timestamp) values ("'.$fname.'", "'.$phone.'", "'.$email.'", "'.$subject.'", "'.$message.'", "'.$ip_address.'", "'.$current_datetime.'")';
		
			$res = $conn->query($query);
			$to = 'testmailowner@yopmail.com'; //considering site owners email address here
			if($res){
				$send = mail($to, $subject, $message);
				
			}
		}
		
			
	}
	?>
</body>
</html>